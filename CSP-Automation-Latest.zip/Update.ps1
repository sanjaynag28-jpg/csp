param(
  [string]$Repo = "sanjaynag28-jpg/csp",
  [string]$Branch = "main",
  [switch]$Silent
)

$ErrorActionPreference = "Stop"

if (-not $Repo -or $Repo -like "*YOUR_GITHUB_USERNAME*" -or $Repo -notlike "*/*") {
  if (-not $Silent) {
    Write-Host "[ERROR] Pehle Update.bat me GITHUB_REPO me apna asli GitHub username/repo daalein." -ForegroundColor Red
  }
  exit 1
}

$dir = $PSScriptRoot
$base = "https://raw.githubusercontent.com/$Repo/$Branch/"
$ts = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

if (-not $Silent) {
  Write-Host "============================================"
  Write-Host "  CSP Automation Helper - Update Check..."
  Write-Host "============================================"
}

try {
  $cfg = Invoke-RestMethod -Uri ($base + "config.json?t=" + $ts) -TimeoutSec 15
  $localManifest = Get-Content (Join-Path $dir "manifest.json") -Raw | ConvertFrom-Json
  $remoteVer = [string]$cfg.version
  $localVer = [string]$localManifest.version
  if (-not $remoteVer) { exit 0 }

  $files = @("manifest.json", "background.js", "content.js", "styles.css", "README.txt")
  $tmp = Join-Path $env:TEMP ("csp_upd_" + $ts)
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $changed = $false

  try {
    foreach ($f in $files) {
      $dst = Join-Path $tmp $f
      Invoke-WebRequest -Uri ($base + $f + "?t=" + $ts) -OutFile $dst -UseBasicParsing -TimeoutSec 20
      if ((Get-Item $dst).Length -lt 20) {
        throw "Downloaded file too small: $f"
      }
      if ($f -eq "manifest.json") {
        Get-Content $dst -Raw | ConvertFrom-Json | Out-Null
      }
    }

    foreach ($f in $files) {
      $newPath = Join-Path $tmp $f
      $oldPath = Join-Path $dir $f
      $newHash = (Get-FileHash $newPath -Algorithm SHA256).Hash
      $oldHash = if (Test-Path $oldPath) { (Get-FileHash $oldPath -Algorithm SHA256).Hash } else { "" }
      if ($newHash -ne $oldHash) {
        Copy-Item $newPath $oldPath -Force
        $changed = $true
      }
    }

    if (-not $Silent) {
      if ($changed) {
        Write-Host "[OK] Update ho gaya: v$localVer -> v$remoteVer" -ForegroundColor Green
        Write-Host "30 second me Chrome Extension apne aap reload ho jayega."
      } else {
        Write-Host "[OK] Aapka Extension pehle se latest version (v$localVer) par hai." -ForegroundColor Cyan
      }
    }
  } finally {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }
} catch {
  if (-not $Silent) {
    Write-Host ("[WARN] Update check nahi ho paya: " + $_.Exception.Message) -ForegroundColor Yellow
  }
  exit 1
}
exit 0

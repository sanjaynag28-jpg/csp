@echo off
setlocal
REM ============================================================
REM  CSP Automation Helper - Free GitHub Auto-Updater
REM  Apna GitHub username/repo neeche 1 jagah set karein:
REM ============================================================
set "GITHUB_REPO=sanjaynag28-jpg/csp"
set "GITHUB_BRANCH=main"

if /I "%~1"=="/silent" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update.ps1" -Repo "%GITHUB_REPO%" -Branch "%GITHUB_BRANCH%" -Silent
  exit /b %errorlevel%
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update.ps1" -Repo "%GITHUB_REPO%" -Branch "%GITHUB_BRANCH%"
echo.
pause
exit /b %errorlevel%

@echo off
setlocal
set "TASK_NAME=CSP-Automation-AutoUpdate"
set "VBS=%~dp0AutoUpdateSilent.vbs"

echo ========================================================
echo   CSP Automation Helper - 1-Time Auto-Update Setup
echo ========================================================
echo.
echo Ye script har 2 ghante aur Windows start hone par
echo apne aap GitHub se naya update check karke install karegi.
echo (Aapka koi bhi customer data kabhi bahar nahi jata.)
echo.

schtasks /Delete /TN "%TASK_NAME%" /F >nul 2>&1
schtasks /Create /TN "%TASK_NAME%" /TR "wscript.exe \"%VBS%\"" /SC HOURLY /MO 2 /F >nul
if errorlevel 1 (
  echo [ERROR] Task setup nahi ho paya. Kripya Right-Click -> Run as administrator karke try karein.
  pause
  exit /b 1
)

schtasks /Create /TN "%TASK_NAME%-Logon" /TR "wscript.exe \"%VBS%\"" /SC ONLOGON /F >nul 2>&1

echo [OK] Auto-Update chalu ho gaya!
echo Ab pehla update check chala rahe hain...
echo.
call "%~dp0Update.bat"
exit /b 0

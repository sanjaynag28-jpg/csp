@echo off
setlocal
set "TASK_NAME=CSP-Automation-AutoUpdate"
schtasks /Delete /TN "%TASK_NAME%" /F >nul 2>&1
schtasks /Delete /TN "%TASK_NAME%-Logon" /F >nul 2>&1
echo [OK] CSP Automation Auto-Update scheduled task hata diya gaya hai.
pause
exit /b 0

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
bat = folder & "\Update.bat"
If fso.FileExists(bat) Then
  shell.Run """" & bat & """ /silent", 0, False
End If
